![logo](_media/logo.png)

# 极致办公 | 批处理办公

## 用最短的时间完成繁杂的工作，提升工作效率

- 各种批处理程序：bat批处理、ps批处理、cdr批处理、python批处理、压缩包批处理、文件批处理、文件夹批处理
  

[GitHub](/README.md)
[开始阅读](README.md)

